import demjson
import json
import csv
f = open("Automation Test Engineer.json","r")
o = open('Data.csv','w')
s = f.read()
writer = csv.writer(o)
text = demjson.decode(s)

for row in json.loads(text.read()):
	writer.writerow(row)



